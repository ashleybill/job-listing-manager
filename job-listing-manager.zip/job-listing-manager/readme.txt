=== Job Listing Manager ===
Contributors: AJB
Tags: jobs, employment, careers, job postings
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage job postings with custom post types and blocks.

== Description ==

Job Listing Manager provides functionality to configure job postings easily with content loaded from a custom post type.

Features:
* Custom Job Listing post type
* Job Categories taxonomy
* Custom fields for job details (location, salary, closing date)
* Block editor support

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/job-listing-manager/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Install and activate Secure Custom Fields (SCF) plugin
4. Create job postings under Jobs menu

== Changelog ==

= 0.1.0 =
* Initial release
